import { Component, createElement } from "react";
import { hot } from "react-hot-loader/root";

import { BadgeSample } from "./components/BadgeSample";
import GlobeComponent from "./components/globe";
import "./ui/MyWidget.css";

class MyWidget extends Component {

    constructor(props) {
        super(props);

        this.onClickHandler = this.onClick.bind(this);
    }

    render() {
        return (
            // // <BadgeSample
            //     type={this.props.mywidgetType}
            //     bootstrapStyle={this.props.bootstrapStyle}
            //     className={this.props.class}
            //     clickable={!!this.props.onClickAction}
            //     defaultValue={this.props.mywidgetValue ? this.props.mywidgetValue : ""}
            //     onClickAction={this.onClickHandler}
            //     style={this.props.style}
            //     value={this.props.valueAttribute ? this.props.valueAttribute.displayValue : ""} />
            <GlobeComponent>

            </GlobeComponent>
        );
    }

    onClick() {
        if (this.props.onClickAction && this.props.onClickAction.canExecute) {
            this.props.onClickAction.execute();
        }
    }
}

export default hot(MyWidget);

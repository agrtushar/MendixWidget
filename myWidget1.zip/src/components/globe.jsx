import React, { Component } from 'react';
import { loadModules } from 'esri-loader';
import PubSub from 'pubsub-js';
import "../ui/MyWidget.css"
//import RightPanelComponent from '../RightPanelComponent/RightPanelComponent';
let globeData = [];
let sceneView;
let myInterval;
const options = {
  url: 'https://js.arcgis.com/4.13/'
};

class GlobeComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sceneState: false,
      globeData : []
    }
  }
  getJSONData = () => {
    
    fetch(`${localStorage.getItem("getApiName")}/GetFacilityDetails?AssetType=Facility`, JSON.parse(localStorage.getItem('apiHeaders')))
        .then(resp => resp.json())
        .then(response => {
          globeData = [...response];
          this.renderTheGlobe();
        })
        .catch(err => {
          
          this.renderTheGlobe();
          console.log(err)
      })
        
        
}

  componentDidMount() {
    this.getJSONData();
    PubSub.subscribe('Division', this.pubsubReceiver);
    // document.getElementById("home-menu").click();
  }
  addMarkersToMap = (view, Graphic) => {
    for (let k = 0; k < globeData.length; k++) {
      let markerColor;
      console.log(globeData);
      let lng = globeData[k].LocationLongitude;
      let lat = globeData[k].LocationLatitude;
      let point = {
        type: "point", // autocasts as new Point()
        longitude: lng,
        latitude: lat
      };
      if(globeData[k].AssetStatus === "2"){
        markerColor = "#da291c";
      } else if(globeData[k].AssetStatus === "1"){
        markerColor = "#ffd602";
      } else{
        markerColor = "#44b02a";
      }
      const markerSymbol = {
        type: "point-3d",  // autocasts as new PointSymbol3D()
        symbolLayers: [{
          type: "object",  // autocasts as new ObjectSymbol3DLayer()
          resource: {
            href: "marker.obj"
          },
          height: 400000,
          width: 100000,
          anchor: "relative",

          anchorPosition: { x: -1.5, y: -0.5, z: -0.5 },
          tilt: 0,

          //roll:-45
          material: {
            color: markerColor
          }
        }]
      };

      // Create a graphic and add the geometry and symbol to it
      let pointGraphic = new Graphic({
        geometry: point,
        symbol: markerSymbol,
        popupTemplate: {
          //title: "<div><img class ='factory-map' src='https://www.baselayer.com/wp-content/uploads/Factory-Floor-Elevated-View_lrg.jpg'></div>",
          title: "<div><img class ='factory-map' src="+globeData[k].ImageSrcPath+"></div>",
          //location: event.mapPoint, // Set the location of the popup to the clicked location
          content: "<div class='plant-details'><div> {locName} </div><div class='loc-details'>{plantName}</div></div>"
        }
        //}
      });
      pointGraphic.attributes = {
        "state": globeData[k].StateCode,
        "locName": globeData[k].CityName,
        "plantName": globeData[k].AssetType,
        "assetGUID":globeData[k].AssetGUID,
        "parentBusiness":globeData[k].ParentBusinessName,
        "businessName" : globeData[k].BusinessName
      };
      view.graphics.addMany([pointGraphic]);
    }
  }

  zoomOnLocation = (lng, lat) => {
    // in this case the view zooms out two LODs on each click
    sceneView.goTo(
      {
        position: {
          x: lng,
          y: lat,
          z: 4000000,
        },
        heading: 0,
        tilt: 0
      },
      {
        speedFactor: 1,
        easing: "linear"
      }
    );
  }
  pubsubReceiver = (channel, data) => {
    if (channel === "GlobeData" ) {
      globeData = data;
    } else {
      if (data[2] != null && data[2] !== "") {
        this.zoomOnLocation(data[2], data[3]);
      }
    }

  };

  //Function to enable animation/rotation of the globe. It will be called every 40 secs to have a rotating globe
  animateTheGlobe = () => {
    sceneView.goTo(this.shiftCamera(270), {
      duration: 40000,
      maxDuration: 40000 // Make sure to set maxDuration if the duration is bigger than 8000 ms
    });
  }

  //Function shifts the globe to a passed degree from its current location
  shiftCamera = (deg) => {
    let camera = sceneView.camera.clone();
    camera.position.longitude += deg;
    return camera;
  }

  //Function to render the globe
  renderTheGlobe = () => {
    loadModules(["esri/views/SceneView", "esri/Graphic", "esri/WebScene", "esri/layers/VectorTileLayer"], options)
      .then(([SceneView, Graphic, WebScene, VectorTileLayer]) => {
        let _that = this;
        let navigateAction = {
          // This text is displayed as a tooltip
          title: "",
          // The ID by which to reference the action in the event handler
          id: "navigate",
        };
        const vtLayer = new VectorTileLayer({      
          style: {
            layers: [
              {
                layout: {},
                paint: {
                  "fill-color": "#E9FAFF"   
                },
                source: "esri",
                minzoom: 0,
                "source-layer": "Land",
                type: "fill",
                id: "Land/0",
              },
              
              {
                layout: {},
                paint: {
                 "fill-color": "#010c14",
                },
                source: "esri",
                minzoom: 0,
                "source-layer": "Marine area",
                type: "fill",
                id: "Marine area/1"
              },
              {
                layout: {
                  "line-cap": "round",
                  "line-join": "round"
                },
                paint: {
                  "line-color": "#010c14",
                  //"line-dasharray": [7, 5],
                  "line-width": 1
                },
                source: "esri",
                minzoom: 1,
                "source-layer": "Boundary line",
                type: "line",
                id: "Boundary line/Admin0/0"
              }
            ],
            glyphs:
              "https://basemaps.arcgis.com/arcgis/rest/services/World_Basemap_v2/VectorTileServer/resources/fonts/{fontstack}/{range}.pbf",
            version: 8,
            sprite:
              "https://www.arcgis.com/sharing/rest/content/items/7675d44bb1e4428aa2c30a9b68f97822/resources/sprites/sprite",
            sources: {
              esri: {
                url:
                  "https://basemaps.arcgis.com/arcgis/rest/services/World_Basemap_v2/VectorTileServer",
                type: "vector"
              }
            },
            metadata: {
              arcgisStyleUrl: "https://www.arcgis.com/sharing/rest/content/items/5e9b3685f4c24d8781073dd928ebda50/resources/styles/root.json",
              arcgisOriginalItemTitle: "Dark Gray Canvas Base"
            }
          }
        });
        // Create the map from the given web scene
        const map = new WebScene({
          layers: vtLayer
        });
        // Create the SceneView
        sceneView = new SceneView({
          map: map,
          container: "viewDiv",
          zoom: 1,
          center: [2970.285846066311358, -920.19552181573599],
          popup: {
            actions: [navigateAction],
            dockEnabled: false,
            dockOptions: {
              buttonEnabled: false,
              breakpoint: false
            }
          },

          highlightOptions: {
            color: [255, 255, 0, 1],
            haloColor: "yellow",
            haloOpacity: 0.9,
            fillOpacity: 1
          },
          environment: {
            lighting: {
              // date: Date.now(), 
            },
            atmosphere: {
              quality: "high"
            }
          }
        });
        // This event fires for each click on any action
        sceneView.popup.on("trigger-action", function (event) {
          var AssetGUIDarray = [];
          // If the navigate action is clicked, fire the navigate() function
          if (event.action.id === "navigate") {
            PubSub.publish("factoryName",event.target.content.graphic.attributes.locName);
            
            PubSub.publish("AssetID",event.target.content.graphic.attributes.assetGUID);
            AssetGUIDarray.push(event.target.content.graphic.attributes.assetGUID);
            localStorage.setItem("pathGUID",JSON.stringify(AssetGUIDarray));
            localStorage.setItem("parentBusiness",event.target.content.graphic.attributes.parentBusiness);
            localStorage.setItem("businessName",event.target.content.graphic.attributes.businessName)
            _that.props.history.push({ pathname: '/factoryFloor' });
            _that.props.changeMenu();
          }
        });
        // Listen for when the scene view is ready
        sceneView.when(function () {
          _that.animateTheGlobe();
          myInterval = setInterval(() => {
            _that.animateTheGlobe();
          }, 39000);
        });
        sceneView.on("click", function (event) {
          sceneView.hitTest(event).then(function (response) {
            if (response.results && response.results.length > 0 && response.results[0].graphic["attributes"].state) {
              _that.zoomOnLocation(event.mapPoint.longitude, event.mapPoint.latitude)
              clearInterval(myInterval);
            }
          })
        });
        // Function to create graphic layer of markers on the map
        this.addMarkersToMap(sceneView, Graphic);
      })

  }


  render() {
    return (
      <div>
        <div className='map-div' id='viewDiv' >
        </div>
      </div>
    )
  }
}

export default GlobeComponent;
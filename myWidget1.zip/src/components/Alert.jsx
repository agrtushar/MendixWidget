import { createElement } from "react";
import classNames from "classnames";

export const Alert = ({ className, bootstrapStyle, message }) =>
    message
        ? (<div className={classNames(`alert alert-${bootstrapStyle}`, className)}>{message}</div>)
        : null;

Alert.displayName = "Alert";
